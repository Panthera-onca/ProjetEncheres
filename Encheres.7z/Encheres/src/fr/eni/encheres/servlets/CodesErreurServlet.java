package fr.eni.encheres.servlets;

public abstract class CodesErreurServlet {
	public static final int CHAMPS_VIDES_SERVLETS = 30000;
	public static final int ERREUR_FORMAT_PRIX = 30001;
    public static final int MONTANT_INSUFFISANT = 30002;
    public static final int FONDS_INSUFFISANTS = 30003;

}
