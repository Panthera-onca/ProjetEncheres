package fr.eni.encheres.bll;

public abstract class CodesErreur {
	public static final int CHAMPS_VIDE_ERREUR = 40000;
	public static final int ERREUR_FORMAT_PSEUDO = 40001;
	public static final int ERREUR_SAISIE_MDP = 40002;
	public static final int ERREUR_DATE = 40003;

}
